const exercicesGuides = [
  {
    id: 'rc-charge', chapitre: 'ch12', titre: 'Charge d’un condensateur', automatisme: false,
    source: 'Vincent Bernardin, CH12_Exercices, exercice 1',
    enonce: 'Un condensateur de capacité C = 100,0 nF est soumis à une tension de 30,0 mV. On cherche la valeur absolue de la charge portée par une armature.',
    etapes: [
      ['Quelle relation relie Q, C et la tension U ?', ['Q = C × U', 'Q = C ÷ U', 'Q = U ÷ C'], 0, 'Un farad correspond à un coulomb par volt.', 'On multiplie la capacité par la tension pour obtenir une charge en coulombs.'],
      ['Que valent C et U dans les unités SI ?', ['1,000 × 10⁻⁴ F et 3,00 × 10⁻² V', '1,000 × 10⁻⁷ F et 3,00 × 10⁻² V', '1,000 × 10⁻⁷ F et 3,00 × 10⁻⁵ V'], 1, 'Nano vaut 10⁻⁹ et milli vaut 10⁻³.', '100,0 nF = 1,000 × 10⁻⁷ F et 30,0 mV = 3,00 × 10⁻² V.'],
      ['Quelle charge obtient-on ?', ['3,00 × 10⁻⁵ C', '3,00 × 10⁻⁷ C', '3,00 × 10⁻⁹ C'], 2, 'Multiplie les coefficients et additionne les exposants.', 'Q = 1,000 × 10⁻⁷ × 3,00 × 10⁻² = 3,00 × 10⁻⁹ C.']
    ]
  },
  {
    id: 'rc-evolution', chapitre: 'ch12', titre: 'Évolution de la charge d’un condensateur', automatisme: true,
    source: 'Vincent Bernardin, CH12_Exercices, rubrique Automatismes',
    enonce: 'Un condensateur initialement déchargé, de capacité C = 70 nF, est placé en série avec un résistor R et un générateur idéal de tension E = 6,0 V. On ferme le circuit à t = 0.',
    etapes: [
      ['Quelle équation vérifie la charge q après la fermeture ?', ['R × dq/dt + q/C = E', 'R × dq/dt − q/C = E', 'q/C = E dès t = 0'], 0, 'La tension du générateur est la somme des tensions du résistor et du condensateur.', 'La loi des mailles donne E = Ri + q/C avec i = dq/dt.'],
      ['Quelle valeur prend q après une longue durée ?', ['0 C', 'E/C', 'CE'], 2, 'En régime permanent, la charge ne varie plus.', 'Lorsque dq/dt = 0, la tension du condensateur vaut E et q = CE.'],
      ['Quelle est cette charge en nanocoulombs ?', ['42 nC', '420 nC', '4 200 nC'], 1, 'En multipliant des nanofarads par des volts, on obtient des nanocoulombs.', '70 × 6,0 = 420 nC.']
    ]
  },
  {
    id: 'diffraction-tp', chapitre: 'ch6', titre: 'Diffraction en TP', automatisme: true,
    source: 'Vincent Bernardin, CH6_Exercices, rubrique Automatismes',
    enonce: 'Un laser éclaire une fente de largeur a. À une distance D, on observe une tache centrale de largeur L. L’angle θ repère le premier minimum de part et d’autre de l’axe. On travaille aux petits angles.',
    etapes: [
      ['Quelle distance sépare le centre du premier minimum sur l’écran ?', ['L/2', 'L', '2L'], 0, 'La tache est symétrique par rapport à l’axe.', 'L est la distance entre les deux premiers minima.'],
      ['Quelle expression géométrique approche θ ?', ['L/D', 'L/(2D)', '2D/L'], 1, 'Écris la tangente de θ dans le triangle rectangle.', 'tan θ = (L/2)/D et tan θ ≈ θ.'],
      ['Sachant que θ ≈ λ/a, quelle expression donne λ ?', ['2aD/L', 'L/(2aD)', 'aL/(2D)'], 2, 'Isole λ dans la relation de diffraction.', 'λ ≈ aθ ≈ aL/(2D).']
    ]
  },
  {
    id: 'eau-oxygenee', chapitre: 'ch13', titre: 'Décomposition de l’eau oxygénée', automatisme: true,
    source: 'Vincent Bernardin, CH13_Exercices VB, rubrique Automatismes',
    enonce: 'On suit la décomposition de 20,0 mol de peroxyde d’hydrogène H₂O₂ en eau et dioxygène. La quantité initiale de dioxygène dans le bilan est nulle. On suppose la transformation totale.',
    etapes: [
      ['Quelle équation est équilibrée ?', ['H₂O₂ → H₂O + O₂', '2 H₂O₂ → 2 H₂O + O₂', '2 H₂O₂ → H₂O + 2 O₂'], 1, 'Compte les atomes de chaque élément de part et d’autre.', 'Les deux membres contiennent quatre H et quatre O.'],
      ['Quel est l’avancement maximal ?', ['20,0 mol', '40,0 mol', '10,0 mol'], 2, 'Deux moles de H₂O₂ sont consommées pour une mole d’avancement.', 'À la fin, 20,0 − 2xₘₐₓ = 0, donc xₘₐₓ = 10,0 mol.'],
      ['Quelle quantité de O₂ faut-il repérer pour lire le temps de demi-réaction ?', ['5,00 mol', '10,0 mol', '20,0 mol'], 0, 'Le coefficient de O₂ vaut 1 et x vaut la moitié de sa valeur finale.', 'La quantité de O₂ formé est x. À la demi-réaction, elle vaut 5,00 mol.']
    ]
  },
  {
    id: 'phosphore-32', chapitre: 'ch15', titre: 'Désintégration du phosphore 32', automatisme: false,
    source: 'Vincent Bernardin, CH15_Exercices, exercice 1',
    enonce: 'Un noyau de phosphore contient 15 protons et 17 neutrons. Il émet un électron en se désintégrant. Le soufre a pour numéro atomique Z = 16.',
    etapes: [
      ['Quel est le nombre de nucléons du noyau initial ?', ['15', '17', '32'], 2, 'Les nucléons sont les protons et les neutrons.', 'Le nombre de masse est A = 15 + 17 = 32.'],
      ['De quel type de radioactivité s’agit-il ?', ['Alpha', 'Bêta moins', 'Bêta plus'], 1, 'Un électron porte une charge négative.', 'L’émission d’un électron caractérise une désintégration bêta moins.'],
      ['Quel noyau fils obtient-on ?', ['Soufre 32', 'Soufre 31', 'Phosphore 31'], 0, 'Conserve le nombre de masse et la charge totale, en tenant compte de l’électron émis.', 'Le noyau fils conserve A = 32. Comme l’électron a pour charge −e, le noyau fils a Z = 16.']
    ]
  }
];

let exerciceEnCours = null;

const badgeAutomatisme = '<span class="guided-automation"><button type="button" class="guided-star" aria-label="Automatisme">★</button><span aria-hidden="true" class="guided-tooltip">Automatisme</span></span>';

const zoneExercicesGuides = document.getElementById('exercise');
zoneExercicesGuides.addEventListener('pointerdown', event => {
  const etoile = event.target.closest('.guided-star');
  if (!etoile || !event.isPrimary || event.button !== 0) return;
  etoile.setPointerCapture(event.pointerId);
  etoile.classList.add('guided-star-held');
});
for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) {
  zoneExercicesGuides.addEventListener(type, event => {
    event.target.closest('.guided-star')?.classList.remove('guided-star-held');
  });
}
zoneExercicesGuides.addEventListener('contextmenu', event => {
  if (event.target.closest('.guided-star')) event.preventDefault();
});

function afficherExercicesGuides() {
  $('#exercise').replaceChildren();
  const chapitre = DATA.chapters.find(ch => ch.id === active);
  const exercices = exercicesGuides.filter(exercice => exercice.chapitre === active);
  const resolus = profile().guidedSolved || {};
  const nombreResolus = exercicesGuides.filter(exercice => resolus[exercice.id]).length;
  $('#stats').innerHTML = '<strong>' + nombreResolus + ' / ' + exercicesGuides.length +
    '</strong> exercices résolus <small>Tous chapitres</small>';
  $('#exercise').innerHTML = '<section class="card guided-card"><h2>' + esc(chapitre?.name) +
    '</h2>' + (exercices.length ? '<ul class="guided-list">' + exercices.map(exercice =>
      '<li>' + (exercice.automatisme ? badgeAutomatisme : '') +
      '<button data-guided="' + esc(exercice.id) + '">' + esc(exercice.titre) +
      (resolus[exercice.id] ? ' <small>· Résolu</small>' : '') + '</button></li>').join('') +
      '</ul>' : '<p>Les exercices guidés de ce chapitre sont en préparation.</p>') + '</section>';
  $('#exercise').querySelectorAll('[data-guided]').forEach(button => {
    button.onclick = () => {
      exerciceEnCours = exercices.find(exercice => exercice.id === button.dataset.guided);
      afficherEtapeGuidee(0);
    };
  });
}

function afficherEtapeGuidee(index) {
  const exercice = exerciceEnCours;
  const [question, options, bonneReponse, indice, explication] = exercice.etapes[index];
  const cours = DATA.interactiveCourses.find(item => item.resourceIds.includes(exercice.chapitre));
  const fiche = resourcesById.has(exercice.chapitre) ? exercice.chapitre : cours?.resourceIds[0];
  $('#exercise').innerHTML = '<section class="card guided-card"><button id="guided-back">Retour aux exercices</button>' +
    '<h2>' + esc(exercice.titre) + '</h2>' + (exercice.automatisme ? badgeAutomatisme : '') +
    '<p>' + esc(exercice.enonce) + '</p><small>Étape ' + (index + 1) + ' / ' + exercice.etapes.length +
    '</small><h3 tabindex="-1" id="guided-question">' + esc(question) + '</h3><div class="guided-list">' +
    options.map((option, choix) => '<button data-guided-choice="' + choix + '">' + esc(option) + '</button>').join('') +
    '</div><p id="guided-feedback" role="status"></p><details><summary>Voir un indice</summary><p>' + esc(indice) +
    '</p>' + (fiche ? '<button type="button" data-sheet="' + esc(fiche) + '">Fiche de révision</button>' : '') +
    (cours ? ' <button type="button" data-course="' + esc(cours.id) + '">Cours H5P</button>' : '') +
    '</details><details id="guided-explanation" hidden><summary>Voir la réponse</summary><p>' + esc(explication) +
    '</p></details><button class="primary" id="guided-next" hidden>' +
    (index + 1 === exercice.etapes.length ? 'Terminer l’exercice' : 'Question suivante') +
    '</button><p><small>D’après ' + esc(exercice.source) + '</small></p></section>';
  $('#guided-back').onclick = afficherExercicesGuides;
  const choix = [...$('#exercise').querySelectorAll('[data-guided-choice]')];
  choix.forEach(button => {
    button.onclick = () => {
      const correct = Number(button.dataset.guidedChoice) === bonneReponse;
      const retour = $('#guided-feedback');
      retour.textContent = correct ? 'Bonne réponse' : 'À revoir. Tu peux ouvrir l’indice et réessayer.';
      retour.className = correct ? 'guided-correct' : 'guided-incorrect';
      if (correct) {
        choix.forEach(option => { option.disabled = true; });
        $('#guided-explanation').hidden = false;
        $('#guided-next').hidden = false;
      }
    };
  });
  $('#guided-next').onclick = () => {
    if (index + 1 < exercice.etapes.length) {
      afficherEtapeGuidee(index + 1);
      return;
    }
    const eleve = profile();
    eleve.guidedSolved ??= {};
    eleve.guidedSolved[exercice.id] = true;
    persist();
    afficherExercicesGuides();
    $('#exercise').querySelector('[data-guided="' + exercice.id + '"]')?.focus();
  };
  const titre = $('#guided-question');
  titre.focus({preventScroll:true});
  titre.scrollIntoView({block:'start', behavior:matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth'});
}
