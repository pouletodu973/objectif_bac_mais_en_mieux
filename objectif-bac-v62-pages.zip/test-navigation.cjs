const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const http = require('node:http');
const path = require('node:path');
const { chromium, firefox, webkit, devices } = require(process.env.OBJECTIF_PLAYWRIGHT || 'playwright');
const types = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8',
  '.css':'text/css; charset=utf-8','.json':'application/json','.png':'image/png',
  '.woff2':'font/woff2','.webmanifest':'application/manifest+json'};
const engine = process.env.OBJECTIF_ENGINE || 'chromium';
const device = process.env.OBJECTIF_DEVICE;

async function localServer() {
  const root = path.resolve(process.env.OBJECTIF_DIR || __dirname);
  const server = http.createServer(async (request,response)=>{
    try {
      const url = new URL(request.url,'http://127.0.0.1');
      const file = path.resolve(root,decodeURIComponent(url.pathname.slice(1)) || 'index.html');
      if (!file.startsWith(root+path.sep)) throw new Error('Chemin hors dossier');
      const bytes = await fs.readFile(file);
      response.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream'});
      response.end(bytes);
    } catch {response.writeHead(404).end();}
  });
  await new Promise((resolve,reject)=>server.once('error',reject).listen(0,'127.0.0.1',resolve));
  return {server,origin:'http://127.0.0.1:'+server.address().port+'/'};
}

(async () => {
  const browser = await { chromium, firefox, webkit }[engine].launch({
    executablePath: process.env.OBJECTIF_BROWSER,
  });
  let server;
  try {
    const site = process.env.OBJECTIF_URL ? {origin:process.env.OBJECTIF_URL} : await localServer();
    server = site.server;
    const {origin} = site;
    const page = await browser.newPage(device ? devices[device] : { viewport: {width:1280,height:800} });
    const failures = [];
    const translations = [];
    if (process.env.OBJECTIF_FIXTURES) {
      await page.route('**/*',async route=>{
        const url = new URL(route.request().url());
        if(url.origin!==new URL(origin).origin)return route.abort();
        const relative=decodeURIComponent(url.pathname.slice(1)) || 'index.html';
        try {
          const target=path.join(__dirname,relative);
          await route.fulfill({body:await fs.readFile(target),contentType:types[path.extname(target)]||'application/octet-stream'});
        } catch { await route.fulfill({status:404,body:'Fichier absent'}); }
      });
    }
    await page.route('https://n8n.incubateur.education.gouv.fr/**', route=>route.abort());
    page.on('pageerror', error => failures.push(error.message));
    page.on('request', request=>{if(request.url().includes('/translations/'))translations.push(request.url());});
    const started = Date.now();
    await page.goto(origin,{waitUntil:'domcontentloaded',timeout:60000});
    await page.locator('#pseudo').fill('Recette locale');
    console.log('Inscription disponible après', Date.now()-started, 'ms');
    console.log(await page.evaluate(()=>{
      const nav=performance.getEntriesByType('navigation')[0];
      return { html:Math.round(nav.responseEnd), dom:Math.round(nav.domContentLoadedEventEnd),
        bytes:nav.encodedBodySize, assets:performance.getEntriesByType('resource').filter(r=>r.duration>500).map(r=>[new URL(r.name).pathname,Math.round(r.duration)]) };
    }));
    assert.equal(translations.length,0);
    await page.locator('#profile-submit').click();
    await page.locator('#tutorial-next').click();
    await page.locator('#tutorial-skip').click();
    await page.locator('#administration > summary').click();
    await page.getByText('Apparence',{exact:true}).click();
    await page.locator('#dark-mode').check();
    assert.equal(await page.locator('html').getAttribute('data-dark'),'');
    await page.locator('#dark-mode').uncheck();
    assert.equal(await page.locator('html').getAttribute('data-dark'),null);
    await page.locator('#dark-mode').check();
    await page.mouse.click(3,3);
    assert.equal(await page.locator('#administration').getAttribute('open'),null);
    await page.locator('#comprendre').click();
    await page.locator('#learn').click();
    const answers = page.locator('.answers button[data-choice]');
    const correct = await page.evaluate(()=>queue[pos].correct);
    const incorrect = answers.locator('xpath=self::button[@data-choice != "'+correct+'"]').first();
    await incorrect.click();
    assert.match(await incorrect.getAttribute('class'),/first-wrong/);
    assert.match(await page.locator('#feedback').innerText(),/Réessayer/);
    assert.equal(await page.locator('#daily52').getAttribute('value'),'0');
    const good = page.locator('.answers button[data-choice="'+correct+'"]');
    await good.click();
    assert.match(await good.getAttribute('class'),/retry-correct/);
    assert.equal(await page.locator('#daily52').getAttribute('value'),'1');
    assert.deepEqual(await page.evaluate(()=>session.map(x=>x.ok)),[true]);
    await page.locator('#feedback .correction summary').click();
    await page.locator('.question').click();
    assert.equal(await page.locator('#feedback .correction').getAttribute('open'),null);
    await page.locator('#feedback-languages summary').click();
    await page.locator('#feedback-languages [data-lang="es"]').click();
    try { await page.waitForFunction(()=>document.querySelector('#feedback [data-feedback-field="explanation"]')?.lang==='es',{},{timeout:12000}); }
    catch (error) {
      console.error('Langue attendue non affichée',translations, failures, await page.locator('#feedback .translation-note').textContent());
      throw error;
    }
    assert.equal(translations.length,1);
    await page.locator('#skip').click();
    if(await answers.count()>2) {
      const valid = await page.evaluate(()=>queue[pos].correct);
      const wrong = page.locator('.answers button[data-choice]:not([data-choice="'+valid+'"])');
      await wrong.first().click();
      await wrong.nth(1).click();
      assert.match(await wrong.nth(1).getAttribute('class'),/wrong/);
      assert.deepEqual(await page.evaluate(()=>session.map(x=>x.ok)),[true,false]);
    }
    await page.locator('#skip').click();
    if(await answers.count()) {
      const valid = await page.evaluate(()=>queue[pos].correct);
      const firstTry = page.locator('.answers button[data-choice="'+valid+'"]');
      await firstTry.click();
      assert.match(await firstTry.getAttribute('class'),/\bcorrect\b/);
      assert.equal(await page.evaluate(()=>session.at(-1).ok),true);
    }
    await page.locator('#calculer').click();
    assert.equal(await page.locator('#entry').inputValue(),'chapters');
    await page.locator('#learn').click();
    if(await page.locator('#calc-toggle').isVisible()){
      await page.locator('#calc-toggle').dblclick();
      assert(await page.locator('#calc-expr').isVisible());
      await page.locator('#calc-expr').fill('2+3');
      await page.locator('#calc-expr').press('Enter');
      assert.match(await page.locator('#calc-output').innerText(),/5/);
      await page.locator('#calc-close').click();
    }
    assert(await page.locator('#bilan-liens li').count()<=4);
    await page.evaluate(()=>{
      activity52(profile()).red['chapter:test']=true;
      actualiserProgression(false);
      persist();
    });
    await page.locator('#star-red').click();
    assert.match(await page.locator('#reward-title52').innerText(),/Flammes jaunes/);
    assert.match(await page.locator('#share52').getByRole('link',{name:'WhatsApp'}).getAttribute('href'),/flamme/);
    await page.locator('#reward52').getByRole('button',{name:'Fermer'}).click();
    const courses = page.locator('#courses');
    await courses.click();
    await page.locator('#course-search').fill('fluides');
    const chapter = page.locator('.course-entry:visible').first();
    await chapter.locator('summary').click();
    await chapter.getByRole('button',{name:'Fiche de révision'}).click();
    assert(await page.locator('.formula-title').getByText('Relation de Bernoulli',{exact:true}).isVisible());
    await page.locator('#lesson-back').click();
    assert.equal(await page.locator('#course-search').inputValue(),'fluides');
    await chapter.getByRole('button',{name:'Ouvrir le cours'}).click();
    const frame = page.locator('#lesson-dialog iframe');
    await frame.waitFor();
    const response = await page.request.get(new URL(await frame.getAttribute('src'),origin).href);
    assert(response.ok());
    await page.locator('#lesson-close').click();
    await page.reload();
    await courses.waitFor();
    assert.equal(await page.locator('#registration').count() && await page.locator('#registration').isVisible(),false);
    assert.equal(await page.locator('#tutorial').isVisible(),false);
    assert.equal(await page.locator('html').getAttribute('data-dark'),'');
    assert(Number(await page.locator('#daily52').getAttribute('value'))>=1);
    assert.deepEqual(failures,[]);
    console.log('Parcours validé',engine,device||'ordinateur');
  } finally {
    server?.close();
    await browser.close();
  }
})().catch(error=>{console.error(error);process.exitCode=1;});
